export default function universidad({params}){
    return(
       <>
      <h1>Estas en universidad</h1>
       <p>{params.id}</p>
       </> 
    );
    
}